# 나만의 날씨 ❄️🌸🌧️🍁🌠 — Android 2.0

갤럭시를 포함한 Android 스마트폰에서 **다른 앱을 사용하는 동안에도 화면 위에 계절 효과를 표시**하는 자체 제작 안드로이드 프로젝트입니다. 화면 터치가 뒤의 앱에 전달되도록 구성했습니다.

**중요: 이 ZIP은 APK가 아닙니다.** Android Studio에서 열어 APK로 빌드해야 합니다. 이 환경에는 Android SDK/Gradle이 없어 실제 컴파일 및 삼성 갤럭시 테스트가 이루어지지 않았습니다. 실행 성공을 보장하지 않으며 오류가 발생하면 빌드 로그를 확인해 수정해야 합니다.

## 2.0 버전: 요청하신 추가 기능 모두 구현

1. ❄️ 눈 / 🌸 벚꽃 / ✨ 눈+벚꽃 / 🌧️ 비 / 🍁 단풍잎 / 🌠 별똥별: **총 6가지 모드**
2. 눈 모양 3종: **동그란 눈, 눈 결정, 반짝 눈**
3. 벚꽃 모양 3종: **꽃잎, 꽃송이, 하트 꽃잎**
4. **흔들어서 흩날리기**: 휴대폰 가속도 센서 감지, 끄기/켜기 설정 가능 (센서 없는 기기에서는 불가)
5. **시간대별 자동 효과**: 아침(06~12), 낮(12~18), 저녁(18~22), 밤(22~06)마다 각각 6가지 모드 중 하나 지정 가능. 시간은 휴대폰 로컬 시간 기준. 실행 중 약 60초마다 시간대 변경을 확인하며, 자동 실행 예약 기능은 아님(앱에서 효과를 먼저 켜야 함).
6. **빠른 설정 타일**: 상단 알림창의 '눈꽃 효과' 버튼으로 켜기/끄기. Android 13(API 33) 이상에서는 앱 안에서 '빠른 설정에 추가' 버튼으로 시스템 추가 요청 가능. 지원하지 않는 기기에서는 알림창 편집으로 직접 추가.

### 이전 기능도 유지

- 입자 수, 속도, 크기, 선명도(투명도) 조절, 자동 저장 및 미리보기
- 사용자가 허용한 `다른 앱 위에 표시` 권한을 사용하는 전체화면 투명 오버레이
- 오버레이가 사용자의 터치와 스크롤을 가로채지 않도록 `FLAG_NOT_TOUCHABLE` 및 창 알파 0.75 설정
- 앱 내 종료, 상단 실행 알림에서 종료
- 불필요한 네트워크 권한·광고·계정·개인정보 수집 없음

## 초보자를 위한 APK 만들기

1. PC에 [Android Studio](https://developer.android.com/studio)를 설치합니다. Android SDK API 35 및 JDK 17을 준비합니다.
2. ZIP을 압축 해제합니다.
3. Android Studio에서 **Open** → 압축 해제한 `SnowPetalAndroid_v2` 폴더 선택. 상단 안내에 따라 Gradle Sync를 진행합니다.
4. 이 소스에는 Gradle Wrapper 실행 파일/JAR가 포함되지 않습니다. Android Studio가 프로젝트 동기화에 실패하면 **새로운 Java/Empty Views 프로젝트를 만든 다음 이 ZIP의 `app/src/main`을 새 프로젝트의 `app/src/main`에 통째로 복사**하는 방법을 권장합니다. 그때 app 모듈의 `namespace`/`applicationId`는 `com.snowpetal.overlay`, minSdk 26, compileSdk 35 이상, Java 17로 맞춥니다.
5. Android Studio의 **Build → Build Bundle(s) / APK(s) → Build APK(s)** 를 실행합니다.
6. 정상 빌드되었다면 `app/build/outputs/apk/debug/app-debug.apk`를 갤럭시로 옮겨 설치합니다.
7. 앱에서 원하는 효과를 선택하고 **화면에 효과 켜기**를 누릅니다. **다른 앱 위에 표시** 권한을 승인합니다. 알림 권한 요청이 나타나면 승인하는 것이 좋습니다.
8. 빠른 설정 버튼은 앱 내부에서 추가를 요청하거나 알림창을 두 번 내려 **편집(연필) → 눈꽃 효과**를 추가합니다.

> 갤럭시 One UI/Android의 권한 및 배터리 정책 때문에 일부 앱(보안 앱, 잠금화면 등)에서는 효과가 표시되지 않거나 서비스가 종료될 수 있습니다. 특히 화면 위 오버레이는 은행/결제 화면에서 차단될 수 있습니다. **알림이나 빠른 설정을 이용해 필요한 때 꺼 주세요.**

## 코드 구조

- `MainActivity.java`: 한국어 설정 UI, 시간대 지정, 모양/강도 선택, 빠른 설정 타일 등록 요청
- `ParticleView.java`: 6종 Canvas 효과, 도형 모양 구현, 센서 흔들기 시 입자 분산
- `OverlayService.java`: 사용자가 시작하는 투명 오버레이, 상단 알림, 센서 구독, 시간대 갱신
- `SnowTileService.java`: 상단 빠른 설정 타일 On/Off
- `Prefs.java`: 설정 보관 및 시간대에 맞는 모드 계산
- `AndroidManifest.xml`: 권한 및 서비스 선언

## 설치·운영 상 유의 사항

- 처음부터 자동으로 켜지거나 재부팅 후 자동 실행되지는 않습니다. 사용자가 화면 효과를 켜야 작동합니다.
- 화면 위에 애니메이션을 계속 그리므로 배터리 소모가 있으며 기본 목표 프레임은 약 30FPS입니다. 배터리를 절약하려면 효과 양을 줄이고 사용하지 않을 때 끄세요.
- 빠른 설정 타일 동작은 기기별 제약이 있을 수 있습니다. 일부 Android 버전에서는 타일에서 직접 포그라운드 서비스 시작이 차단될 수 있어 앱 화면으로 이동하도록 처리했습니다.
- 권한은 화면 오버레이, 실행 중 서비스, Android 13+ 알림으로 제한됩니다. 흔들기 효과는 일반 가속도 센서를 사용하며 별도 활동 인식 권한을 요구하지 않습니다.
- 제3자 AiOO Snow의 소스나 그래픽을 그대로 사용하지 않았으며 화면 효과를 독립 구현했습니다.
- 스토어 배포에는 추가적인 개인정보 처리 안내 및 스토어 정책 검토가 필요할 수 있습니다.

## 참고 공식 개발 문서

- [오버레이 권한](https://developer.android.com/reference/android/Manifest.permission#SYSTEM_ALERT_WINDOW)
- [터치 통과 오버레이 관련 정책](https://developer.android.com/reference/android/view/WindowManager.LayoutParams#FLAG_NOT_TOUCHABLE)
- [Quick Settings TileService](https://developer.android.com/reference/android/service/quicksettings/TileService)
- [빠른 설정 타일 추가 요청 (Android 13+)](https://developer.android.com/reference/android/app/StatusBarManager#requestAddTileService(android.content.ComponentName,java.lang.CharSequence,android.graphics.drawable.Icon,java.util.concurrent.Executor,java.util.function.Consumer))
- [포그라운드 서비스 유형](https://developer.android.com/develop/background-work/services/fgs/service-types)

## 컴퓨터 없이 GitHub에서 APK 빌드하기 (선택)

프로젝트에 `.github/workflows/build-apk.yml`이 포함되어 있어, GitHub 계정과 인터넷이 있으면 온라인 빌드를 시도할 수 있습니다.

1. GitHub에 **새 비공개 저장소**를 만들고 ZIP을 푼 프로젝트의 파일 및 `.github` 폴더를 모두 업로드합니다. 소스 파일들은 저장소 맨 위(루트)에 두어야 합니다.
2. 저장소의 **Actions → Build Android debug APK → Run workflow**를 선택합니다. 저장소 설정에 따라 Actions 사용 허용이 필요할 수 있습니다.
3. 빌드 성공 시 해당 작업의 **Artifacts → snowpetal-debug-apk** 압축 파일을 내려받아 압축을 풉니다.
4. 추출한 `app-debug.apk`를 갤럭시에 설치합니다.

이 방법 역시 현재 환경에서는 GitHub 빌드를 실행·검증하지 않았습니다. GitHub의 정책, 무료 사용량, Android/Gradle 버전에 따라 실패하거나 비용이 발생할 수 있습니다.
