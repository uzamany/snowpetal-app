package com.snowpetal.overlay;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.provider.Settings;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** User-added Quick Settings tile: tap to toggle the floating animation. */
public final class SnowTileService extends TileService {
    static void requestTileRefresh(Context context) {
        try {
            requestListeningState(context, new ComponentName(context, SnowTileService.class));
        } catch (RuntimeException ignored) { }
    }

    @Override public void onStartListening() {
        super.onStartListening();
        refreshTile();
    }

    @Override public void onTileAdded() {
        super.onTileAdded();
        refreshTile();
    }

    private void refreshTile() {
        Tile tile = getQsTile();
        if (tile == null) return;
        tile.setLabel("눈꽃 효과");
        tile.setIcon(Icon.createWithResource(this, R.drawable.ic_weather));
        tile.setState(OverlayService.isActive ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        if (Build.VERSION.SDK_INT >= 29) {
            tile.setSubtitle(OverlayService.isActive ? "켜짐" : "꺼짐");
        }
        tile.updateTile();
    }

    @Override public void onClick() {
        super.onClick();
        if (OverlayService.isActive) {
            stopService(new Intent(this, OverlayService.class));
            refreshTile();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            openActivityToGrantPermission();
            return;
        }
        Intent start = new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_START);
        try {
            startForegroundService(start);
        } catch (RuntimeException e) {
            // Some OS versions disallow FGS launch from a tile; use a visible Activity.
            openActivityToGrantPermission();
        }
        refreshTile();
    }

    private void openActivityToGrantPermission() {
        Intent open = new Intent(this, MainActivity.class);
        open.putExtra(MainActivity.EXTRA_FROM_TILE, true);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (Build.VERSION.SDK_INT >= 34) {
            PendingIntent pending = PendingIntent.getActivity(this, 29, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            startActivityAndCollapse(pending);
        } else {
            startActivityAndCollapse(open);
        }
    }
}
