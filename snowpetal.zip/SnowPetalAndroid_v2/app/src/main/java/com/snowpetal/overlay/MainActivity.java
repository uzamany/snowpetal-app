package com.snowpetal.overlay;

import android.Manifest;
import android.app.Activity;
import android.app.StatusBarManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Self-contained Korean configuration screen, without appcompat or network dependencies. */
public final class MainActivity extends Activity {
    public static final String EXTRA_FROM_TILE = "start_requested_from_tile";
    private static final int INK = 0xFFF5F1FF;
    private static final int MUTED = 0xFFB5B5D3;
    private static final int SURFACE = 0xFF232640;
    private static final int ACCENT = 0xFFE4ACDC;
    private final Button[] modeButtons = new Button[Prefs.MODE_NAMES.length];
    private ParticleView preview;
    private TextView status;
    private TextView automaticDescription;
    private TextView quickTileInfo;
    private Button startButton;
    private Switch autoSwitch;
    private boolean pendingStart;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF11132B);
        getWindow().setNavigationBarColor(0xFF11132B);
        buildUI();
        refreshUI();
        if (getIntent().getBooleanExtra(EXTRA_FROM_TILE, false)) {
            getIntent().removeExtra(EXTRA_FROM_TILE);
            startButton.post(this::askPermissionThenStart);
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra(EXTRA_FROM_TILE, false)) {
            intent.removeExtra(EXTRA_FROM_TILE);
            if (startButton != null) startButton.post(this::askPermissionThenStart);
        }
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable gradient(int... colors) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(dp(24));
        return d;
    }

    private LinearLayout.LayoutParams vp(int height, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height < 0 ? height : dp(height));
        p.topMargin = dp(top);
        return p;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout panel() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(17));
        card.setBackground(shape(SURFACE, 20));
        return card;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTextColor(INK);
        b.setText(label);
        b.setBackground(shape(0xFF3B3E5B, 12));
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private void buildUI() {
        SharedPreferences prefs = Prefs.get(this);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFF11132B);
        scroll.setClipToPadding(false);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            scroll.setPadding(0, insets.getSystemWindowInsetTop(), 0,
                    insets.getSystemWindowInsetBottom());
            return insets;
        });
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(38));
        scroll.addView(root);
        setContentView(scroll);

        TextView eyebrow = text("✦  SNOW · PETAL  2.0", 12, 0xFFD8A8CF, true);
        eyebrow.setLetterSpacing(.1f);
        root.addView(eyebrow);
        root.addView(text("나만의 날씨  ❄️🌸", 29, INK, true), vp(-2, 5));
        root.addView(text("다른 앱 위에 내리는 눈, 꽃잎 그리고 별빛", 13, MUTED, false), vp(-2, 4));

        FrameLayout previewCard = new FrameLayout(this);
        previewCard.setBackground(gradient(0xFF25294E, 0xFF412B55, 0xFF623657));
        previewCard.setClipToOutline(true);
        root.addView(previewCard, vp(190, 20));
        TextView previewHint = text("오늘의 화면에 작은 계절을", 19, Color.WHITE, true);
        FrameLayout.LayoutParams hintParams = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        previewCard.addView(previewHint, hintParams);
        preview = new ParticleView(this);
        previewCard.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        TextView previewLabel = text("LIVE PREVIEW", 11, 0xFFF6DEEA, true);
        FrameLayout.LayoutParams labelParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        labelParams.leftMargin = dp(16);
        labelParams.topMargin = dp(14);
        previewCard.addView(previewLabel, labelParams);

        root.addView(text("효과 선택", 18, INK, true), vp(-2, 23));
        root.addView(text("6가지 효과 중 하나를 골라보세요", 12, MUTED, false), vp(-2, 4));
        for (int rowIndex = 0; rowIndex < 3; rowIndex++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            root.addView(row, vp(52, rowIndex == 0 ? 12 : 7));
            for (int column = 0; column < 2; column++) {
                int mode = rowIndex * 2 + column;
                Button b = smallButton(Prefs.MODE_SYMBOLS[mode] + " " + Prefs.MODE_NAMES[mode]);
                b.setTextSize(15);
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, -1, 1f);
                if (column == 1) bp.leftMargin = dp(8);
                row.addView(b, bp);
                modeButtons[mode] = b;
                b.setOnClickListener(v -> {
                    prefs.edit().putBoolean(Prefs.AUTO, false).putInt(Prefs.MODE, mode).apply();
                    if (autoSwitch != null) autoSwitch.setChecked(false);
                    refreshModeButtons();
                    refreshAutomaticHint();
                    notifySettingsChanged();
                });
            }
        }
        refreshModeButtons();

        LinearLayout settingsCard = panel();
        root.addView(settingsCard, vp(-2, 17));
        settingsCard.addView(text("효과 강도", 17, INK, true));
        addSlider(settingsCard, "내리는 양", Prefs.AMOUNT, 45, "적게", "많이");
        addSlider(settingsCard, "이동 속도", Prefs.SPEED, 50, "천천히", "빠르게");
        addSlider(settingsCard, "입자 크기", Prefs.SIZE, 50, "작게", "크게");
        addSlider(settingsCard, "투명도 / 선명도", Prefs.OPACITY, 75, "연하게", "선명하게");

        LinearLayout shapeCard = panel();
        root.addView(shapeCard, vp(-2, 13));
        shapeCard.addView(text("모양 꾸미기", 17, INK, true));
        shapeCard.addView(text("오른쪽 버튼을 누를 때마다 모양이 바뀝니다", 12, MUTED, false), vp(-2, 5));
        addCycleRow(shapeCard, "❄️ 눈 모양", Prefs.SNOW_SHAPE, 0,
                Prefs.SNOW_SHAPES, null);
        addCycleRow(shapeCard, "🌸 벚꽃 모양", Prefs.PETAL_SHAPE, 0,
                Prefs.PETAL_SHAPES, null);

        LinearLayout autoCard = panel();
        root.addView(autoCard, vp(-2, 13));
        LinearLayout automaticRow = new LinearLayout(this);
        automaticRow.setGravity(Gravity.CENTER_VERTICAL);
        autoCard.addView(automaticRow);
        TextView automaticTitle = text("🕒 시간대별 자동 변경", 17, INK, true);
        automaticRow.addView(automaticTitle, new LinearLayout.LayoutParams(0, -2, 1));
        autoSwitch = new Switch(this);
        autoSwitch.setChecked(prefs.getBoolean(Prefs.AUTO, false));
        autoSwitch.setContentDescription("시간대별 자동 변경 켜기 또는 끄기");
        automaticRow.addView(autoSwitch);
        automaticDescription = text("", 12, MUTED, false);
        autoCard.addView(automaticDescription, vp(-2, 6));
        autoCard.addView(text("아래 버튼을 눌러 시간대별 효과를 선택하세요", 11, MUTED, false), vp(-2, 8));
        addCycleRow(autoCard, "🌅 아침 06~12시", Prefs.MORNING, Prefs.CHERRY,
                Prefs.MODE_NAMES, Prefs.MODE_SYMBOLS);
        addCycleRow(autoCard, "☀️ 낮 12~18시", Prefs.AFTERNOON, Prefs.LEAF,
                Prefs.MODE_NAMES, Prefs.MODE_SYMBOLS);
        addCycleRow(autoCard, "🌆 저녁 18~22시", Prefs.EVENING, Prefs.SHOOTING_STAR,
                Prefs.MODE_NAMES, Prefs.MODE_SYMBOLS);
        addCycleRow(autoCard, "🌙 밤 22~06시", Prefs.NIGHT, Prefs.SNOW,
                Prefs.MODE_NAMES, Prefs.MODE_SYMBOLS);
        autoSwitch.setOnCheckedChangeListener((view, checked) -> {
            prefs.edit().putBoolean(Prefs.AUTO, checked).apply();
            refreshModeButtons();
            refreshAutomaticHint();
            notifySettingsChanged();
        });
        refreshAutomaticHint();

        LinearLayout shakeCard = panel();
        root.addView(shakeCard, vp(-2, 13));
        LinearLayout shakeRow = new LinearLayout(this);
        shakeRow.setGravity(Gravity.CENTER_VERTICAL);
        shakeCard.addView(shakeRow);
        TextView shakeTitle = text("📳 휴대폰 흔들면 흩날리기", 16, INK, true);
        shakeRow.addView(shakeTitle, new LinearLayout.LayoutParams(0, -2, 1));
        Switch shakeSwitch = new Switch(this);
        shakeSwitch.setChecked(prefs.getBoolean(Prefs.SHAKE, false));
        shakeSwitch.setContentDescription("흔들기 효과 켜기 또는 끄기");
        shakeRow.addView(shakeSwitch);
        shakeCard.addView(text("가속도 센서로 흔들림을 감지합니다. 센서가 없는 기기에서는 동작하지 않습니다.",
                12, MUTED, false), vp(-2, 5));
        shakeSwitch.setOnCheckedChangeListener((view, checked) -> {
            prefs.edit().putBoolean(Prefs.SHAKE, checked).apply();
            notifySettingsChanged();
        });

        LinearLayout tileCard = panel();
        root.addView(tileCard, vp(-2, 13));
        tileCard.addView(text("⚡ 빠른 설정 버튼", 17, INK, true));
        tileCard.addView(text("알림창의 빠른 설정에서 효과를 켜거나 끌 수 있어요", 12, MUTED, false), vp(-2, 6));
        Button tileButton = smallButton("빠른 설정에 '눈꽃 효과' 추가하기");
        tileCard.addView(tileButton, vp(48, 12));
        quickTileInfo = text("알림창을 두 번 내린 뒤 '편집'에서도 추가할 수 있습니다.", 11, MUTED, false);
        tileCard.addView(quickTileInfo, vp(-2, 7));
        tileButton.setOnClickListener(v -> requestQuickTile());

        status = text("", 13, MUTED, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, vp(-2, 19));
        startButton = new Button(this);
        startButton.setAllCaps(false);
        startButton.setTextSize(17);
        startButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        startButton.setTextColor(0xFF2B2038);
        startButton.setBackground(gradient(0xFFFFE4F2, 0xFFF2A9D0));
        startButton.setOnClickListener(v -> askPermissionThenStart());
        root.addView(startButton, vp(58, 9));

        Button stop = smallButton("화면 효과 종료하기");
        stop.setTextSize(14);
        stop.setOnClickListener(v -> {
            pendingStart = false;
            stopService(new Intent(this, OverlayService.class));
            refreshUI();
        });
        root.addView(stop, vp(51, 9));
        TextView footer = text("인터넷·로그인·광고 없음 · 터치 통과 · 언제든 종료 가능", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, vp(-2, 16));
    }

    private void addCycleRow(LinearLayout parent, String label, String key, int defaultValue,
                             String[] choices, String[] emojis) {
        SharedPreferences prefs = Prefs.get(this);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        parent.addView(row, vp(48, 7));
        TextView name = text(label, 13, INK, false);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        Button change = smallButton("");
        row.addView(change, new LinearLayout.LayoutParams(dp(143), dp(42)));
        Runnable updateLabel = () -> {
            int selected = prefs.getInt(key, defaultValue);
            if (selected < 0 || selected >= choices.length) selected = 0;
            change.setText((emojis == null ? "" : emojis[selected] + " ") + choices[selected] + "  ↻");
        };
        updateLabel.run();
        change.setOnClickListener(v -> {
            int next = (prefs.getInt(key, defaultValue) + 1) % choices.length;
            prefs.edit().putInt(key, next).apply();
            updateLabel.run();
            refreshAutomaticHint();
            notifySettingsChanged();
        });
    }

    private void addSlider(LinearLayout parent, String label, String key, int defaultValue,
                           String left, String right) {
        SharedPreferences prefs = Prefs.get(this);
        LinearLayout entry = new LinearLayout(this);
        entry.setOrientation(LinearLayout.VERTICAL);
        parent.addView(entry, vp(-2, 12));
        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        entry.addView(heading);
        heading.addView(text(label, 14, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView value = text(prefs.getInt(key, defaultValue) + "%", 12, ACCENT, true);
        heading.addView(value);
        SeekBar seek = new SeekBar(this);
        seek.setMax(100);
        seek.setProgress(prefs.getInt(key, defaultValue));
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFFFD7E9));
        seek.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF555A77));
        entry.addView(seek, vp(34, 3));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                value.setText(progress + "%");
                if (fromUser) {
                    prefs.edit().putInt(key, progress).apply();
                    notifySettingsChanged();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        LinearLayout scale = new LinearLayout(this);
        entry.addView(scale);
        scale.addView(text(left, 11, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1));
        scale.addView(text(right, 11, MUTED, false));
    }

    private void refreshModeButtons() {
        SharedPreferences prefs = Prefs.get(this);
        boolean auto = prefs.getBoolean(Prefs.AUTO, false);
        int current = Prefs.currentMode(prefs);
        for (int i = 0; i < modeButtons.length; i++) {
            Button b = modeButtons[i];
            if (b == null) continue;
            boolean selected = current == i;
            b.setTextColor(selected ? 0xFF291E3B : INK);
            b.setBackground(shape(selected ? 0xFFF3B7DE : 0xFF343650, 14));
            b.setAlpha(auto ? .72f : 1f);
        }
    }

    private void refreshAutomaticHint() {
        if (automaticDescription != null) {
            SharedPreferences prefs = Prefs.get(this);
            automaticDescription.setText(prefs.getBoolean(Prefs.AUTO, false)
                    ? "자동 변경 실행 중 · 현재 " + Prefs.currentModeLabel(prefs)
                    : "꺼짐 · 직접 고른 효과를 계속 보여줍니다");
        }
        refreshModeButtons();
    }

    private void notifySettingsChanged() {
        if (preview != null) preview.reloadSettings();
        if (OverlayService.isActive) {
            Intent update = new Intent(this, OverlayService.class);
            update.setAction(OverlayService.ACTION_UPDATE);
            try { startService(update); } catch (RuntimeException ignored) { }
        }
    }

    private void requestQuickTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            StatusBarManager bar = getSystemService(StatusBarManager.class);
            if (bar != null) {
                bar.requestAddTileService(new ComponentName(this, SnowTileService.class),
                        "눈꽃 효과", Icon.createWithResource(this, R.drawable.ic_weather),
                        getMainExecutor(), result -> {
                            if (quickTileInfo == null) return;
                            quickTileInfo.setText(result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED
                                    ? "✓ 빠른 설정에 추가했습니다. 알림창에서 확인하세요."
                                    : "추가되지 않았다면 알림창 → 편집에서 '눈꽃 효과'를 추가하세요.");
                        });
                return;
            }
        }
        quickTileInfo.setText("알림창을 두 번 내리고 편집(연필) → '눈꽃 효과'를 추가하세요.");
    }

    private void askPermissionThenStart() {
        if (!Settings.canDrawOverlays(this)) {
            pendingStart = true;
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (RuntimeException e) {
                status.setText("설정에서 '다른 앱 위에 표시' 권한을 허용해 주세요.");
            }
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 32);
            return;
        }
        activateOverlay();
    }

    private void activateOverlay() {
        Intent start = new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_START);
        try {
            startForegroundService(start);
            status.setText("● 효과 시작을 요청했습니다");
            status.setTextColor(0xFFB6E9CD);
            startButton.setText("✨ 현재 설정 적용하기");
        } catch (RuntimeException e) {
            status.setText("효과를 시작하지 못했습니다. 앱 권한과 배터리 설정을 확인해 주세요.");
            status.setTextColor(0xFFFFC0C0);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                                       int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 32) activateOverlay();
    }

    @Override protected void onResume() {
        super.onResume();
        if (pendingStart) {
            pendingStart = false;
            if (Settings.canDrawOverlays(this)) askPermissionThenStart();
        }
        refreshAutomaticHint();
        if (preview != null) preview.reloadSettings();
        refreshUI();
        if (status != null) status.postDelayed(this::refreshUI, 450);
    }

    private void refreshUI() {
        if (status == null || startButton == null) return;
        if (OverlayService.isActive) {
            status.setText("● 화면 효과 실행 중 · " + Prefs.currentModeLabel(Prefs.get(this)));
            status.setTextColor(0xFFB6E9CD);
            startButton.setText("✨ 현재 설정 적용하기");
        } else {
            status.setText("○ 현재 화면 효과가 꺼져 있어요");
            status.setTextColor(MUTED);
            startButton.setText("✨ 화면에 효과 켜기");
        }
    }
}
