package com.snowpetal.overlay;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Calendar;

/** Settings shared by the Activity, overlay service, preview and Quick Settings tile. */
final class Prefs {
    static final String NAME = "snowpetal_prefs";
    static final String MODE = "mode";
    static final String AMOUNT = "amount";
    static final String SPEED = "speed";
    static final String SIZE = "size";
    static final String OPACITY = "opacity";
    static final String SNOW_SHAPE = "snow_shape";
    static final String PETAL_SHAPE = "petal_shape";
    static final String SHAKE = "shake_effect";
    static final String AUTO = "auto_time";
    static final String MORNING = "slot_morning";
    static final String AFTERNOON = "slot_afternoon";
    static final String EVENING = "slot_evening";
    static final String NIGHT = "slot_night";

    static final int SNOW = 0;
    static final int CHERRY = 1;
    static final int MIXED = 2;
    static final int RAIN = 3;
    static final int LEAF = 4;
    static final int SHOOTING_STAR = 5;

    static final String[] MODE_NAMES = {"눈", "벚꽃", "눈+벚꽃", "비", "단풍", "별똥별"};
    static final String[] MODE_SYMBOLS = {"❄️", "🌸", "✨", "🌧️", "🍁", "🌠"};
    static final String[] SNOW_SHAPES = {"동그란 눈", "눈 결정", "반짝 눈"};
    static final String[] PETAL_SHAPES = {"꽃잎", "꽃송이", "하트 꽃잎"};

    static SharedPreferences get(Context context) {
        return context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    private static int safeMode(int mode) {
        return mode >= 0 && mode < MODE_NAMES.length ? mode : SNOW;
    }

    static int currentMode(SharedPreferences p) {
        return modeAtHour(p, Calendar.getInstance().get(Calendar.HOUR_OF_DAY));
    }

    // Pure selection logic; split out for deterministic tests at time boundaries.
    static int modeAtHour(SharedPreferences p, int hour) {
        if (!p.getBoolean(AUTO, false)) return safeMode(p.getInt(MODE, SNOW));
        if (hour >= 6 && hour < 12) return safeMode(p.getInt(MORNING, CHERRY));
        if (hour >= 12 && hour < 18) return safeMode(p.getInt(AFTERNOON, LEAF));
        if (hour >= 18 && hour < 22) return safeMode(p.getInt(EVENING, SHOOTING_STAR));
        return safeMode(p.getInt(NIGHT, SNOW));
    }

    static String currentModeLabel(SharedPreferences prefs) {
        int mode = currentMode(prefs);
        return MODE_SYMBOLS[mode] + " " + MODE_NAMES[mode];
    }

    private Prefs() { }
}
