package com.snowpetal.overlay;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

/** Lightweight Canvas overlay: 6 weather/season effects and two configurable shapes. */
public final class ParticleView extends View {
    private static final int MAX_PARTICLES = 110;
    private static final long FRAME_DELAY_MS = 32L;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final ArrayList<Particle> particles = new ArrayList<>();
    private final Random random = new Random();
    private final float dp;
    private boolean destroyed = false;
    private long lastFrameMs;
    private long lastAutoCheckMs;
    private int mode = -1;
    private int count;
    private int snowShape;
    private int petalShape;
    private float speedFactor;
    private float sizeFactor;
    private float userOpacity;

    private static final class Particle {
        float x, y, radius, velocity, wobble, wobbleRate, phase, angle, spin, opacity;
        float kickX, kickY;
        int kind, tint;
    }

    public ParticleView(Context context) {
        super(context);
        dp = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        reloadSettings();
    }

    public void reloadSettings() {
        SharedPreferences p = Prefs.get(getContext());
        int nextMode = Prefs.currentMode(p);
        int desiredCount = nextMode == Prefs.SHOOTING_STAR
                ? 2 + Math.round(p.getInt(Prefs.AMOUNT, 45) * .06f)
                : Math.min(MAX_PARTICLES, 9 + Math.round(p.getInt(Prefs.AMOUNT, 45) * .87f));
        speedFactor = .45f + p.getInt(Prefs.SPEED, 50) / 100f * 1.8f;
        sizeFactor = .55f + p.getInt(Prefs.SIZE, 50) / 100f * 1.3f;
        userOpacity = .25f + p.getInt(Prefs.OPACITY, 75) / 100f * .75f;
        snowShape = Math.max(0, Math.min(2, p.getInt(Prefs.SNOW_SHAPE, 0)));
        petalShape = Math.max(0, Math.min(2, p.getInt(Prefs.PETAL_SHAPE, 0)));
        if (nextMode != mode || desiredCount != count || particles.isEmpty()) {
            mode = nextMode;
            count = desiredCount;
            populate();
        }
        invalidate();
    }

    private void populate() {
        particles.clear();
        if (getWidth() <= 0 || getHeight() <= 0) return;
        for (int i = 0; i < count; i++) {
            Particle p = new Particle();
            resetParticle(p, true);
            particles.add(p);
        }
    }

    private void resetParticle(Particle p, boolean anywhere) {
        p.kind = mode == Prefs.MIXED ? (random.nextBoolean() ? Prefs.SNOW : Prefs.CHERRY) : mode;
        float w = Math.max(1, getWidth());
        float h = Math.max(1, getHeight());
        p.x = random.nextFloat() * w;
        p.y = anywhere ? random.nextFloat() * h : -dp * (15f + random.nextFloat() * 85f);
        p.kickX = 0;
        p.kickY = 0;
        p.phase = random.nextFloat() * 6.28318f;
        p.angle = random.nextFloat() * 360f;
        p.opacity = .55f + random.nextFloat() * .45f;
        p.wobbleRate = .5f + random.nextFloat() * 1.8f;
        p.spin = (random.nextFloat() - .5f) * 155f;
        switch (p.kind) {
            case Prefs.CHERRY:
                p.radius = (5f + random.nextFloat() * 5.2f) * dp;
                p.velocity = (30f + random.nextFloat() * 55f) * dp;
                p.wobble = (12f + random.nextFloat() * 23f) * dp;
                p.tint = random.nextBoolean() ? 0xFFFFB7D7 : 0xFFFFDAE9;
                break;
            case Prefs.RAIN:
                p.radius = (1f + random.nextFloat() * 1.2f) * dp;
                p.velocity = (210f + random.nextFloat() * 195f) * dp;
                p.wobble = (-7f - random.nextFloat() * 11f) * dp;
                p.tint = random.nextBoolean() ? 0xFFB5E3FF : 0xFFDEF4FF;
                break;
            case Prefs.LEAF:
                p.radius = (7.5f + random.nextFloat() * 6f) * dp;
                p.velocity = (27f + random.nextFloat() * 57f) * dp;
                p.wobble = (17f + random.nextFloat() * 22f) * dp;
                int[] colors = {0xFFFFCB56, 0xFFE77B4B, 0xFFFF9B34, 0xFFD74F49};
                p.tint = colors[random.nextInt(colors.length)];
                break;
            case Prefs.SHOOTING_STAR:
                p.radius = (1.5f + random.nextFloat() * 2.8f) * dp;
                p.velocity = (180f + random.nextFloat() * 200f) * dp;
                p.wobble = random.nextBoolean() ? 1f : -1f;
                p.tint = random.nextBoolean() ? 0xFFFFF4D5 : 0xFFDFF5FF;
                // Comets travel diagonally across the display, not straight down.
                p.x = random.nextFloat() * w;
                p.y = anywhere ? random.nextFloat() * h : -(20 + random.nextFloat() * h * .45f);
                p.opacity = .65f + random.nextFloat() * .35f;
                break;
            case Prefs.SNOW:
            default:
                p.radius = (1.5f + random.nextFloat() * 3.9f) * dp;
                p.velocity = (32f + random.nextFloat() * 68f) * dp;
                p.wobble = (6f + random.nextFloat() * 19f) * dp;
                p.tint = random.nextBoolean() ? Color.WHITE : 0xFFD9F4FF;
                break;
        }
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        populate();
    }

    /** Triggered by the accelerometer; pulses objects outward and then naturally slows. */
    public void scatter() {
        if (destroyed) return;
        for (Particle p : particles) {
            p.kickX += (random.nextFloat() - .5f) * 650f * dp;
            p.kickY += (-100f - random.nextFloat() * 275f) * dp;
            p.spin += (random.nextFloat() - .5f) * 300f;
        }
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (destroyed) return;
        long now = SystemClock.uptimeMillis();
        float seconds = lastFrameMs == 0 ? 0f : Math.max(0f, Math.min(.05f, (now - lastFrameMs) / 1000f));
        lastFrameMs = now;
        // Also refresh the preview when the hour changes while this Activity is open.
        if (now - lastAutoCheckMs > 20_000L) {
            lastAutoCheckMs = now;
            SharedPreferences prefs = Prefs.get(getContext());
            if (prefs.getBoolean(Prefs.AUTO, false) && Prefs.currentMode(prefs) != mode) reloadSettings();
        }
        if (particles.isEmpty() && getWidth() > 0 && getHeight() > 0) populate();
        for (Particle p : particles) {
            p.y += (p.velocity * speedFactor + p.kickY) * seconds;
            p.phase += p.wobbleRate * seconds;
            p.angle += p.spin * seconds;
            p.x += p.kickX * seconds;
            float damping = (float) Math.exp(-4.5f * seconds);
            p.kickX *= damping;
            p.kickY *= damping;

            float wobble = p.kind == Prefs.RAIN ? p.wobble * seconds :
                    (float) Math.sin(p.phase) * p.wobble;
            float drawX = p.x + wobble;
            float r = p.radius * sizeFactor;
            if (p.kind == Prefs.SHOOTING_STAR) {
                float direction = p.wobble;
                p.x += direction * p.velocity * speedFactor * .7f * seconds;
                drawX = p.x;
            }
            if (p.y > getHeight() + r * 7f || p.x < -getWidth() * .6f
                    || p.x > getWidth() * 1.6f) {
                resetParticle(p, false);
                continue;
            }
            switch (p.kind) {
                case Prefs.CHERRY: drawPetal(canvas, p, drawX, r); break;
                case Prefs.RAIN: drawRain(canvas, p, drawX, r); break;
                case Prefs.LEAF: drawLeaf(canvas, p, drawX, r); break;
                case Prefs.SHOOTING_STAR: drawComet(canvas, p, drawX, r); break;
                default: drawSnow(canvas, p, drawX, r); break;
            }
        }
        postInvalidateDelayed(FRAME_DELAY_MS);
    }

    private int alpha(Particle p) {
        return Math.max(0, Math.min(255, (int) (p.opacity * userOpacity * 255f)));
    }

    private void drawSnow(Canvas c, Particle p, float x, float r) {
        int a = alpha(p);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(p.tint);
        if (snowShape == 0) {
            paint.setAlpha((int) (a * .23f));
            c.drawCircle(x, p.y, r * 1.8f, paint);
            paint.setAlpha(a);
            c.drawCircle(x, p.y, r, paint);
        } else if (snowShape == 1) {
            paint.setAlpha(a);
            paint.setStrokeWidth(Math.max(dp, r * .22f));
            paint.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 6; i++) {
                float d = (float) (Math.PI / 3 * i);
                float x2 = (float) Math.cos(d);
                float y2 = (float) Math.sin(d);
                c.drawLine(x - r * x2, p.y - r * y2, x + r * x2, p.y + r * y2, paint);
            }
            c.drawCircle(x, p.y, r * .24f, paint);
        } else {
            drawStarPath(x, p.y, r * 1.4f, 4);
            paint.setAlpha(a);
            c.drawPath(path, paint);
        }
    }

    private void drawPetal(Canvas c, Particle p, float x, float r) {
        int a = alpha(p);
        c.save();
        c.translate(x, p.y);
        c.rotate(p.angle);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(p.tint);
        paint.setAlpha(a);
        if (petalShape == 1) {
            for (int i = 0; i < 5; i++) {
                c.save();
                c.rotate(i * 72f);
                c.drawOval(-r * .4f, -r * 1.1f, r * .4f, r * .1f, paint);
                c.restore();
            }
            paint.setColor(0xFFFFEFC7);
            paint.setAlpha(a);
            c.drawCircle(0, 0, r * .22f, paint);
        } else if (petalShape == 2) {
            path.reset();
            path.moveTo(0, r * .95f);
            path.cubicTo(-1.8f * r, -.08f * r, -1.05f * r, -1.3f * r, 0, -.6f * r);
            path.cubicTo(1.05f * r, -1.3f * r, 1.8f * r, -.08f * r, 0, r * .95f);
            c.drawPath(path, paint);
        } else {
            path.reset();
            path.moveTo(0, r * .82f);
            path.cubicTo(-r, r * .05f, -.95f * r, -.85f * r, -.15f * r, -.9f * r);
            path.cubicTo(0, -.65f * r, .1f * r, -.65f * r, .2f * r, -.9f * r);
            path.cubicTo(r, -.76f * r, .85f * r, .2f * r, 0, r * .82f);
            path.close();
            c.drawPath(path, paint);
        }
        c.restore();
    }

    private void drawRain(Canvas c, Particle p, float x, float r) {
        int a = alpha(p);
        paint.setColor(p.tint);
        paint.setAlpha(a);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(.8f * dp, r * .7f));
        float length = (10f + r * 4.5f) * sizeFactor;
        c.drawLine(x + r, p.y - length, x - r * .65f, p.y + length * .1f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawLeaf(Canvas c, Particle p, float x, float r) {
        int a = alpha(p);
        c.save();
        c.translate(x, p.y);
        c.rotate(p.angle);
        path.reset();
        path.moveTo(0, r * 1.0f);
        path.lineTo(-r * .22f, r * .34f);
        path.lineTo(-r * .9f, r * .36f);
        path.lineTo(-r * .61f, -r * .04f);
        path.lineTo(-r * 1.0f, -r * .5f);
        path.lineTo(-r * .39f, -r * .44f);
        path.lineTo(0, -r * 1.05f);
        path.lineTo(r * .39f, -r * .44f);
        path.lineTo(r * 1.0f, -r * .5f);
        path.lineTo(r * .61f, -r * .04f);
        path.lineTo(r * .9f, r * .36f);
        path.lineTo(r * .22f, r * .34f);
        path.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(p.tint);
        paint.setAlpha(a);
        c.drawPath(path, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(0xFF8A4330);
        paint.setAlpha((int)(a * .42f));
        paint.setStrokeWidth(Math.max(.7f * dp, r * .07f));
        c.drawLine(0, r * .75f, 0, -r * .8f, paint);
        paint.setStyle(Paint.Style.FILL);
        c.restore();
    }

    private void drawComet(Canvas c, Particle p, float x, float r) {
        int a = alpha(p);
        float length = (24f + p.radius / dp * 8f) * dp * sizeFactor;
        float dx = p.wobble > 0 ? 1f : -1f;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(dp, r * .85f));
        paint.setColor(p.tint);
        paint.setAlpha((int) (a * .48f));
        c.drawLine(x - dx * length, p.y - length * .8f, x, p.y, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(a);
        c.drawCircle(x, p.y, r * 1.35f, paint);
        paint.setColor(Color.WHITE);
        paint.setAlpha((int) (a * .8f));
        c.drawCircle(x, p.y, r * .6f, paint);
    }

    private void drawStarPath(float cx, float cy, float radius, int points) {
        path.reset();
        for (int i = 0; i < points * 2; i++) {
            double angle = Math.PI * i / points - Math.PI / 2;
            float r = (i % 2 == 0) ? radius : radius * .33f;
            float x = cx + (float) Math.cos(angle) * r;
            float y = cy + (float) Math.sin(angle) * r;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        path.close();
    }

    public void shutdown() {
        destroyed = true;
        lastFrameMs = 0;
    }

    @Override protected void onDetachedFromWindow() {
        shutdown();
        super.onDetachedFromWindow();
    }
}
