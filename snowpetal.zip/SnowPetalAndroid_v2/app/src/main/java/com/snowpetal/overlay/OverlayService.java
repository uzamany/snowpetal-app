package com.snowpetal.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;

/** Foreground, touch-through overlay. The Activity/Quick Settings tile explicitly starts it. */
public final class OverlayService extends Service implements SensorEventListener {
    public static final String ACTION_START = "com.snowpetal.overlay.START";
    public static final String ACTION_UPDATE = "com.snowpetal.overlay.UPDATE";
    public static final String ACTION_STOP = "com.snowpetal.overlay.STOP";
    public static volatile boolean isActive = false;

    private static final int NOTIFICATION_ID = 804;
    private static final String CHANNEL_ID = "snowpetal_effect";
    private WindowManager windowManager;
    private ParticleView particleView;
    private SensorManager sensors;
    private Sensor accelerometer;
    private boolean listeningToShakes;
    private boolean gravityReady;
    private final float[] gravity = new float[3];
    private long lastShakeAt;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable timeWatcher = new Runnable() {
        @Override public void run() {
            if (particleView != null && Prefs.get(OverlayService.this).getBoolean(Prefs.AUTO, false)) {
                particleView.reloadSettings();
                updateNotification();
            }
            handler.postDelayed(this, 60_000L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensors != null) accelerometer = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "화면 계절 효과", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("화면 위 날씨/계절 효과가 실행되는 동안 표시됩니다.");
        manager.createNotificationChannel(channel);
        handler.postDelayed(timeWatcher, 60_000L);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, makeNotification(),
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIFICATION_ID, makeNotification());
            }
        } catch (RuntimeException e) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (particleView == null) {
            particleView = new ParticleView(this);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            // Android 12+: keep this single touch-through overlay below the 0.8 obscuring threshold.
            params.alpha = .75f;
            params.setTitle("SnowPetal touch-through effects");
            try {
                windowManager.addView(particleView, params);
                isActive = true;
            } catch (RuntimeException e) {
                particleView.shutdown();
                particleView = null;
                stopSelf();
                return START_NOT_STICKY;
            }
        } else {
            particleView.reloadSettings();
        }
        configureSensor();
        SnowTileService.requestTileRefresh(this);
        return START_NOT_STICKY;
    }

    private void configureSensor() {
        boolean shouldListen = Prefs.get(this).getBoolean(Prefs.SHAKE, false)
                && accelerometer != null;
        if (shouldListen == listeningToShakes) return;
        if (sensors == null) return;
        if (listeningToShakes) {
            sensors.unregisterListener(this);
            listeningToShakes = false;
        }
        gravityReady = false;
        if (shouldListen) {
            listeningToShakes = sensors.registerListener(this, accelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (particleView == null || event.sensor.getType() != Sensor.TYPE_ACCELEROMETER) return;
        if (!gravityReady) {
            System.arraycopy(event.values, 0, gravity, 0, 3);
            gravityReady = true;
            return;
        }
        float total = 0f;
        for (int i = 0; i < 3; i++) {
            gravity[i] = .8f * gravity[i] + .2f * event.values[i];
            float delta = event.values[i] - gravity[i];
            total += delta * delta;
        }
        long now = SystemClock.elapsedRealtime();
        if (total > 12.5f * 12.5f && now - lastShakeAt > 900L) {
            lastShakeAt = now;
            particleView.scatter();
        }
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private Notification makeNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openIntent = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_weather)
                .setContentTitle("✨ " + Prefs.currentModeLabel(Prefs.get(this)) + " 효과 실행 중")
                .setContentText("눌러서 설정 · '효과 종료'로 끄기")
                .setContentIntent(openIntent)
                .addAction(new Notification.Action.Builder(null, "효과 종료", stopIntent).build())
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void updateNotification() {
        if (isActive) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.notify(NOTIFICATION_ID, makeNotification());
        }
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(timeWatcher);
        if (sensors != null && listeningToShakes) sensors.unregisterListener(this);
        listeningToShakes = false;
        isActive = false;
        if (particleView != null) {
            particleView.shutdown();
            try { windowManager.removeView(particleView); }
            catch (RuntimeException ignored) { }
            particleView = null;
        }
        SnowTileService.requestTileRefresh(this);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
